# POFund — PO Financing Tracker for South African SMMEs

A mobile-first web app that guides SMMEs through the end-to-end purchase order funding process: deal tracking, profitability calculation, and funder comparison.

---

## Features

| Tab | What it does |
|---|---|
| **📊 Process** | 10-step interactive deal tracker with per-step checklists, actor badges, and field insights. Progress persists across page refreshes via `localStorage`. |
| **🧮 Calculator** | Live profitability modeller (PO value, COGS %, logistics, funder fee). Instant margin verdict with go/no-go. |
| **🏦 Funders** | Filterable comparison table of 6 SA funders (Fintech / Specialist / Bank), deal timeline summary, and SMME benefit primer. |

---

## Quick start

```bash
# 1. Install dependencies
npm install

# 2. Start dev server (opens http://localhost:3000)
npm run dev

# 3. Production build → dist/
npm run build

# 4. Preview the production build locally
npm run preview
```

**Node requirement:** 18+

---

## Project structure

```
pofund/
├── index.html                  # Entry point & global CSS resets
├── vite.config.js
├── package.json
├── netlify.toml                # Netlify SPA redirect
├── vercel.json                 # Vercel SPA rewrite
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx                # ReactDOM.createRoot
    ├── App.jsx                 # Shell: header, tab nav, footer
    ├── tokens.js               # Design tokens (palette)
    ├── data/
    │   └── index.js            # STEPS, STEP_DETAILS, FUNDERS, TIMELINE, WHY_SMMES
    ├── hooks/
    │   └── useLocalStorage.js  # Persists deal progress across refreshes
    └── components/
        ├── StepPill.jsx        # Scrollable step indicator pill
        ├── Checklist.jsx       # Per-step interactive checklist (sessionStorage)
        ├── ProcessTab.jsx      # 10-step deal tracker UI
        ├── CalculatorTab.jsx   # Slider-based profit calculator
        └── FundersTab.jsx      # Funder cards + timeline + why SMMEs
```

---

## Deploy

### Vercel (recommended — zero config)

```bash
npm i -g vercel
vercel
```

Or connect your GitHub repo at [vercel.com](https://vercel.com) — it auto-detects Vite.

### Netlify

```bash
npm i -g netlify-cli
netlify deploy --prod --dir=dist
```

Or drag the `dist/` folder to [app.netlify.com/drop](https://app.netlify.com/drop).

### GitHub Pages

```bash
# vite.config.js: add base: '/pofund/' if serving from a sub-path
npm run build
# Push dist/ to gh-pages branch
```

---

## Customisation

| What | Where |
|---|---|
| Colours & palette | `src/tokens.js` |
| Step content, checklists, tips | `src/data/index.js` → `STEP_DETAILS` |
| Funder list & URLs | `src/data/index.js` → `FUNDERS` |
| Calculator defaults | `src/components/CalculatorTab.jsx` → `useState` initialisers |

---

## Roadmap ideas

- [ ] Deal name / reference input so users can track multiple POs
- [ ] Export deal summary as PDF
- [ ] Email checklist to self
- [ ] PWA manifest for Add to Home Screen on mobile
- [ ] Admin CMS for funder data (Sanity / Contentful)

---

## Disclaimer

Data is for information purposes only. Funder fees, advance percentages, and timelines are representative and subject to change. Always verify current terms directly with your chosen funder.
