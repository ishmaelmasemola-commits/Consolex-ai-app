import { useState, useEffect } from 'react'

/**
 * Persists state to localStorage so deal progress survives page refresh.
 */
export function useLocalStorage(key, initialValue) {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key)
      return item ? JSON.parse(item) : initialValue
    } catch {
      return initialValue
    }
  })

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(storedValue))
    } catch {
      // Storage may be unavailable in private browsing
    }
  }, [key, storedValue])

  return [storedValue, setStoredValue]
}
