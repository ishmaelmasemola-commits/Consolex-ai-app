import { useState } from 'react'
import { C } from './tokens.js'
import { useLocalStorage } from './hooks/useLocalStorage.js'
import ProcessTab from './components/ProcessTab.jsx'
import CalculatorTab from './components/CalculatorTab.jsx'
import FundersTab from './components/FundersTab.jsx'

const TABS = [
  { id: 'process',    label: '📊 Process'    },
  { id: 'calculator', label: '🧮 Calculator' },
  { id: 'funders',    label: '🏦 Funders'    },
]

export default function App() {
  const [tab, setTab]           = useState('process')
  const [activeStep, setActiveStep]       = useLocalStorage('pofund-active-step', 1)
  const [completedArr, setCompletedArr]   = useLocalStorage('pofund-completed', [])

  // Set is not JSON-serialisable, so we bridge via an array
  const completedSteps = new Set(completedArr)
  const setCompletedSteps = (updater) => {
    const next = typeof updater === 'function' ? updater(completedSteps) : updater
    setCompletedArr([...next])
  }

  const progressPct = (completedSteps.size / 10) * 100

  const handleReset = () => {
    setCompletedArr([])
    setActiveStep(1)
    // Clear per-step checklist state
    for (let i = 1; i <= 10; i++) {
      try { sessionStorage.removeItem(`checklist-step-${i}`) } catch {}
    }
  }

  return (
    <div
      style={{
        fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif",
        background: C.canvas,
        minHeight: '100dvh',
        maxWidth: 480,
        margin: '0 auto',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* ── Header ─────────────────────────────────────────── */}
      <header style={{ background: C.navy, padding: '20px 20px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          {/* Logo */}
          <div
            style={{
              width: 36,
              height: 36,
              borderRadius: 8,
              background: `linear-gradient(135deg, ${C.gold}, ${C.goldLt})`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 18,
              fontWeight: 800,
              color: C.navy,
              flexShrink: 0,
              userSelect: 'none',
            }}
          >
            ₽
          </div>
          <div>
            <div
              style={{
                fontSize: 16,
                fontWeight: 800,
                color: 'white',
                letterSpacing: '-0.02em',
              }}
            >
              POFund
            </div>
            <div
              style={{
                fontSize: 10,
                color: 'rgba(255,255,255,0.4)',
                letterSpacing: '0.04em',
                textTransform: 'uppercase',
              }}
            >
              Purchase Order Financing · South Africa
            </div>
          </div>
          <button
            onClick={handleReset}
            title="Reset deal progress"
            style={{
              marginLeft: 'auto',
              fontSize: 10,
              color: 'rgba(255,255,255,0.35)',
              background: 'none',
              border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: 6,
              padding: '4px 10px',
              cursor: 'pointer',
            }}
          >
            Reset
          </button>
        </div>

        {/* Progress bar */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
            <span
              style={{
                fontSize: 10,
                color: 'rgba(255,255,255,0.4)',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
              }}
            >
              Deal Progress
            </span>
            <span style={{ fontSize: 10, fontWeight: 700, color: C.goldLt }}>
              {completedSteps.size}/10 steps
            </span>
          </div>
          <div
            style={{
              height: 4,
              background: 'rgba(255,255,255,0.08)',
              borderRadius: 4,
              overflow: 'hidden',
            }}
          >
            <div
              style={{
                height: '100%',
                width: `${progressPct}%`,
                background: `linear-gradient(90deg, ${C.gold}, ${C.goldLt})`,
                borderRadius: 4,
                transition: 'width 0.4s ease',
              }}
            />
          </div>
        </div>

        {/* Tab nav */}
        <nav style={{ display: 'flex', gap: 4 }}>
          {TABS.map(({ id, label }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              aria-current={tab === id ? 'page' : undefined}
              style={{
                flex: 1,
                padding: '7px 4px',
                borderRadius: 7,
                fontSize: 11,
                fontWeight: 600,
                cursor: 'pointer',
                border: 'none',
                transition: 'all 0.15s',
                background: tab === id ? 'rgba(255,255,255,0.12)' : 'transparent',
                color: tab === id ? 'white' : 'rgba(255,255,255,0.38)',
              }}
            >
              {label}
            </button>
          ))}
        </nav>
      </header>

      {/* ── Tab panels ─────────────────────────────────────── */}
      {tab === 'process' && (
        <ProcessTab
          activeStep={activeStep}
          setActiveStep={setActiveStep}
          completedSteps={completedSteps}
          setCompletedSteps={setCompletedSteps}
        />
      )}

      {tab === 'calculator' && (
        <div style={{ flex: 1, padding: 20, overflowY: 'auto' }}>
          <CalculatorTab />
        </div>
      )}

      {tab === 'funders' && (
        <div style={{ flex: 1, padding: 16, overflowY: 'auto' }}>
          <FundersTab />
        </div>
      )}

      {/* ── Footer ─────────────────────────────────────────── */}
      <footer style={{ background: C.navy, padding: '10px 20px', textAlign: 'center' }}>
        <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.25)', margin: 0 }}>
          For information purposes only · Always verify with your chosen funder · South Africa
        </p>
      </footer>
    </div>
  )
}
