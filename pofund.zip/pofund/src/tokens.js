/**
 * POFund design tokens
 * Palette: deep navy + warm gold + sage green + off-white canvas
 * "Formal capital meets township hustle"
 */
export const C = {
  navy:     '#0D1B2A',
  navyMid:  '#1A2E45',
  navyLt:   '#243B55',
  gold:     '#D4920A',
  goldLt:   '#F0B429',
  sienna:   '#C0522A',
  sage:     '#2A7D4F',
  sageDk:   '#1a6e3c',
  canvas:   '#F5F1EB',
  canvasLt: '#FDFBF8',
  ink:      '#0D1B2A',
  muted:    '#6B7A8D',
  border:   '#DDD8CF',
  white:    '#FFFFFF',
}
