import { useState } from 'react'
import { C } from '../tokens.js'
import { FUNDERS, TIMELINE, WHY_SMMES } from '../data/index.js'

const TYPE_COLORS = {
  Fintech:    { bg: '#dbeafe', text: '#1e40af' },
  Specialist: { bg: '#f3e8ff', text: '#5b21b6' },
  Bank:       { bg: '#fef3c7', text: '#92400e' },
}

export default function FundersTab() {
  const [filter, setFilter] = useState('All')
  const types = ['All', 'Fintech', 'Specialist', 'Bank']
  const visible = filter === 'All' ? FUNDERS : FUNDERS.filter((f) => f.type === filter)

  return (
    <div>
      <h3 style={{ fontSize: 15, fontWeight: 700, color: C.ink, marginBottom: 4 }}>
        SA PO Funders — Quick Comparison
      </h3>
      <p style={{ fontSize: 12, color: C.muted, marginBottom: 16, lineHeight: 1.5 }}>
        Representative market data. Always confirm current rates directly with the funder.
      </p>

      {/* Filter pills */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 16, flexWrap: 'wrap' }}>
        {types.map((t) => (
          <button
            key={t}
            onClick={() => setFilter(t)}
            style={{
              padding: '5px 12px',
              borderRadius: 20,
              fontSize: 11,
              fontWeight: 600,
              cursor: 'pointer',
              border: `1.5px solid ${filter === t ? C.gold : C.border}`,
              background: filter === t ? C.gold : 'white',
              color: filter === t ? 'white' : C.muted,
              transition: 'all 0.15s',
            }}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Funder cards */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20 }}>
        {visible.map((f) => {
          const tc = TYPE_COLORS[f.type] || { bg: C.border, text: C.muted }
          return (
            <div
              key={f.name}
              style={{
                border: `1.5px solid ${C.border}`,
                borderRadius: 10,
                padding: '12px 14px',
                background: C.canvasLt,
              }}
            >
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  marginBottom: 10,
                }}
              >
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: C.ink }}>{f.name}</div>
                  <div style={{ fontSize: 10, color: C.muted, marginTop: 2 }}>{f.strength}</div>
                </div>
                <span
                  style={{
                    fontSize: 10,
                    fontWeight: 700,
                    padding: '3px 8px',
                    borderRadius: 20,
                    background: tc.bg,
                    color: tc.text,
                    whiteSpace: 'nowrap',
                  }}
                >
                  {f.type}
                </span>
              </div>

              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr 1fr 1fr',
                  gap: 8,
                  marginBottom: 10,
                }}
              >
                {[
                  ['Fee', f.fee],
                  ['Advance', f.advance],
                  ['Min Deal', f.min],
                  ['Speed', f.speed],
                ].map(([k, v]) => (
                  <div
                    key={k}
                    style={{ background: C.canvas, borderRadius: 6, padding: '6px 8px' }}
                  >
                    <div
                      style={{
                        fontSize: 9,
                        color: C.muted,
                        textTransform: 'uppercase',
                        letterSpacing: '0.04em',
                      }}
                    >
                      {k}
                    </div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: C.ink, marginTop: 1 }}>
                      {v}
                    </div>
                  </div>
                ))}
              </div>

              <a
                href={f.url}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: 'inline-block',
                  fontSize: 11,
                  fontWeight: 600,
                  color: C.gold,
                  textDecoration: 'none',
                  borderBottom: `1px solid ${C.gold}55`,
                  paddingBottom: 1,
                }}
              >
                Visit funder →
              </a>
            </div>
          )
        })}
      </div>

      {/* Timeline */}
      <div style={{ background: C.navy, borderRadius: 12, padding: 16, marginBottom: 12 }}>
        <div
          style={{ fontSize: 12, fontWeight: 700, color: C.goldLt, marginBottom: 12 }}
        >
          ⏱ Typical Deal Timeline
        </div>
        {TIMELINE.map(({ label, value, highlight }) => (
          <div
            key={label}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              padding: '7px 0',
              borderBottom: '1px solid rgba(255,255,255,0.07)',
            }}
          >
            <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>{label}</span>
            <span
              style={{
                fontSize: 12,
                fontWeight: 600,
                color: highlight ? '#68d391' : 'white',
              }}
            >
              {value}
            </span>
          </div>
        ))}
      </div>

      {/* Why SMMEs */}
      <div
        style={{
          background: C.canvasLt,
          border: `1.5px solid ${C.border}`,
          borderRadius: 12,
          padding: 16,
        }}
      >
        <div style={{ fontSize: 12, fontWeight: 700, color: C.ink, marginBottom: 10 }}>
          Why SMMEs Choose PO Funding
        </div>
        {WHY_SMMES.map(({ icon, text }) => (
          <div
            key={text}
            style={{
              display: 'flex',
              gap: 10,
              alignItems: 'flex-start',
              marginBottom: 8,
            }}
          >
            <span style={{ fontSize: 14, flexShrink: 0 }}>{icon}</span>
            <span style={{ fontSize: 12, color: C.ink, lineHeight: 1.4 }}>{text}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
