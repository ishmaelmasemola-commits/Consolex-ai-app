import { C } from '../tokens.js'

export default function StepPill({ step, isActive, isComplete, onClick }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={isActive}
      aria-label={`Step ${step.id}: ${step.label}`}
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 4,
        padding: '8px 6px',
        borderRadius: 10,
        cursor: 'pointer',
        border: 'none',
        background: isActive ? step.color : isComplete ? 'rgba(42,125,79,0.12)' : 'transparent',
        transition: 'all 0.2s',
        minWidth: 60,
        outline: isActive ? `2px solid ${step.color}` : 'none',
        flexShrink: 0,
      }}
    >
      <div
        style={{
          width: 36,
          height: 36,
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: isActive ? 'white' : isComplete ? C.sage : C.border,
          fontSize: 16,
          transition: 'all 0.2s',
          boxShadow: isActive ? `0 2px 8px ${step.color}55` : 'none',
        }}
      >
        {isComplete && !isActive ? '✓' : step.icon}
      </div>
      <span
        style={{
          fontSize: 9,
          fontWeight: 600,
          textAlign: 'center',
          lineHeight: 1.2,
          color: isActive ? 'white' : isComplete ? C.sage : C.muted,
          textTransform: 'uppercase',
          letterSpacing: '0.04em',
        }}
      >
        {step.short}
      </span>
    </button>
  )
}
