import { useState } from 'react'
import { C } from '../tokens.js'

export default function Checklist({ items, storageKey }) {
  // Initialise from sessionStorage per-step so checks survive tab switches
  const [checked, setChecked] = useState(() => {
    try {
      const saved = sessionStorage.getItem(storageKey)
      return saved ? JSON.parse(saved) : {}
    } catch {
      return {}
    }
  })

  const toggle = (i) => {
    const next = { ...checked, [i]: !checked[i] }
    setChecked(next)
    try { sessionStorage.setItem(storageKey, JSON.stringify(next)) } catch {}
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {items.map((item, i) => (
        <button
          key={i}
          onClick={() => toggle(i)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: '6px 0',
            textAlign: 'left',
          }}
        >
          <div
            style={{
              width: 18,
              height: 18,
              borderRadius: 4,
              flexShrink: 0,
              border: `2px solid ${checked[i] ? C.sage : C.border}`,
              background: checked[i] ? C.sage : 'white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.15s',
            }}
          >
            {checked[i] && (
              <span style={{ color: 'white', fontSize: 11, fontWeight: 700 }}>✓</span>
            )}
          </div>
          <span
            style={{
              fontSize: 13,
              color: checked[i] ? C.muted : C.ink,
              textDecoration: checked[i] ? 'line-through' : 'none',
              transition: 'all 0.15s',
            }}
          >
            {item}
          </span>
        </button>
      ))}
    </div>
  )
}
