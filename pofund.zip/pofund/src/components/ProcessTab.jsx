import { useRef, useEffect } from 'react'
import { C } from '../tokens.js'
import { STEPS, STEP_DETAILS } from '../data/index.js'
import StepPill from './StepPill.jsx'
import Checklist from './Checklist.jsx'

export default function ProcessTab({
  activeStep,
  setActiveStep,
  completedSteps,
  setCompletedSteps,
}) {
  const detail = STEP_DETAILS[activeStep]
  const step = STEPS[activeStep - 1]
  const railRef = useRef(null)

  // Auto-scroll the step rail to keep active pill visible
  useEffect(() => {
    const rail = railRef.current
    if (!rail) return
    const pill = rail.children[activeStep - 1]
    if (pill) {
      const pillLeft = pill.offsetLeft
      const pillWidth = pill.offsetWidth
      const railWidth = rail.offsetWidth
      rail.scrollTo({ left: pillLeft - railWidth / 2 + pillWidth / 2, behavior: 'smooth' })
    }
  }, [activeStep])

  const markComplete = () => {
    setCompletedSteps((prev) => new Set([...prev, activeStep]))
    if (activeStep < 10) setActiveStep(activeStep + 1)
  }

  const isDone = completedSteps.has(activeStep)

  return (
    <>
      {/* Step rail */}
      <div
        ref={railRef}
        className="step-rail"
        style={{
          background: C.navyMid,
          padding: '12px 16px',
          overflowX: 'auto',
          display: 'flex',
          gap: 4,
        }}
      >
        {STEPS.map((s) => (
          <StepPill
            key={s.id}
            step={s}
            isActive={activeStep === s.id}
            isComplete={completedSteps.has(s.id) && activeStep !== s.id}
            onClick={() => setActiveStep(s.id)}
          />
        ))}
      </div>

      {/* Step detail */}
      <div style={{ flex: 1, padding: 16, overflowY: 'auto' }}>
        {/* Header card */}
        <div
          style={{
            background: step.color,
            borderRadius: 12,
            padding: '14px 16px',
            marginBottom: 14,
            position: 'relative',
            overflow: 'hidden',
          }}
        >
          <div
            style={{
              position: 'absolute',
              top: -10,
              right: -10,
              fontSize: 60,
              opacity: 0.12,
              lineHeight: 1,
              pointerEvents: 'none',
              userSelect: 'none',
            }}
          >
            {step.icon}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <span
              style={{
                fontSize: 10,
                fontWeight: 700,
                color: 'rgba(255,255,255,0.6)',
                textTransform: 'uppercase',
                letterSpacing: '0.06em',
              }}
            >
              Step {step.id} of 10
            </span>
            <span
              style={{
                fontSize: 10,
                fontWeight: 700,
                padding: '2px 8px',
                borderRadius: 10,
                background:
                  detail.actorColor === C.gold
                    ? 'rgba(0,0,0,0.2)'
                    : 'rgba(255,255,255,0.15)',
                color: 'white',
              }}
            >
              {detail.actor}
            </span>
          </div>
          <div
            style={{
              fontSize: 18,
              fontWeight: 800,
              color: 'white',
              letterSpacing: '-0.02em',
              lineHeight: 1.2,
            }}
          >
            {step.label}
          </div>
        </div>

        {/* Description */}
        <p style={{ fontSize: 13, color: C.ink, lineHeight: 1.6, marginBottom: 16 }}>
          {detail.description}
        </p>

        {/* Checklist */}
        <div
          style={{
            background: C.canvasLt,
            border: `1.5px solid ${C.border}`,
            borderRadius: 10,
            padding: '12px 14px',
            marginBottom: 14,
          }}
        >
          <div
            style={{
              fontSize: 11,
              fontWeight: 700,
              color: C.muted,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              marginBottom: 10,
            }}
          >
            Checklist — tap to mark done
          </div>
          <Checklist items={detail.checklist} storageKey={`checklist-step-${activeStep}`} />
        </div>

        {/* Field insight */}
        <div
          style={{
            background: 'linear-gradient(135deg, rgba(212,146,10,0.08), rgba(212,146,10,0.03))',
            border: '1.5px solid rgba(212,146,10,0.25)',
            borderRadius: 10,
            padding: '11px 13px',
            marginBottom: 16,
          }}
        >
          <div
            style={{
              fontSize: 10,
              fontWeight: 800,
              color: C.gold,
              textTransform: 'uppercase',
              letterSpacing: '0.06em',
              marginBottom: 4,
            }}
          >
            💡 Field insight
          </div>
          <p style={{ fontSize: 12, color: C.ink, lineHeight: 1.5, margin: 0 }}>{detail.tip}</p>
        </div>

        {/* Nav buttons */}
        <div style={{ display: 'flex', gap: 8 }}>
          {activeStep > 1 && (
            <button
              onClick={() => setActiveStep(activeStep - 1)}
              style={{
                flex: 1,
                padding: '11px 0',
                borderRadius: 8,
                fontSize: 12,
                fontWeight: 600,
                cursor: 'pointer',
                border: `1.5px solid ${C.border}`,
                background: 'white',
                color: C.muted,
              }}
            >
              ← Back
            </button>
          )}
          <button
            onClick={markComplete}
            style={{
              flex: 2,
              padding: '12px 0',
              borderRadius: 8,
              fontSize: 13,
              fontWeight: 700,
              cursor: 'pointer',
              border: 'none',
              background: isDone
                ? `linear-gradient(135deg, ${C.sage}, ${C.sageDk})`
                : `linear-gradient(135deg, ${C.gold}, ${C.goldLt})`,
              color: 'white',
              boxShadow: `0 2px 12px ${isDone ? C.sage : C.gold}44`,
              transition: 'all 0.2s',
            }}
          >
            {isDone
              ? activeStep < 10
                ? 'Next Step →'
                : '🎯 Deal Complete!'
              : activeStep < 10
              ? 'Mark Done & Continue →'
              : 'Complete Deal ✓'}
          </button>
        </div>

        {/* Completion banner */}
        {completedSteps.size === 10 && (
          <div
            style={{
              marginTop: 14,
              background: C.sage,
              borderRadius: 10,
              padding: '12px 14px',
              textAlign: 'center',
            }}
          >
            <div style={{ fontSize: 20, marginBottom: 4 }}>🎉</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: 'white' }}>
              Full cycle completed!
            </div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)', marginTop: 2 }}>
              Your SMME just fulfilled a PO-funded deal.
            </div>
          </div>
        )}
      </div>
    </>
  )
}
