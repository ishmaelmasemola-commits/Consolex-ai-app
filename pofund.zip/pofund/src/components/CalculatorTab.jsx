import { useState } from 'react'
import { C } from '../tokens.js'

function formatZAR(n) {
  return new Intl.NumberFormat('en-ZA', {
    style: 'currency',
    currency: 'ZAR',
    maximumFractionDigits: 0,
  }).format(n)
}

function Slider({ label, value, onChange, min, max, step = 1, displayValue }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
        <span style={{ fontSize: 12, color: C.muted, fontWeight: 500 }}>{label}</span>
        <span style={{ fontSize: 13, fontWeight: 700, color: C.ink }}>{displayValue}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        style={{ width: '100%', accentColor: C.gold, background: C.border }}
      />
    </div>
  )
}

export default function CalculatorTab() {
  const [poValue, setPoValue]     = useState(500000)
  const [cogsPct, setCogsPct]     = useState(65)
  const [funderFee, setFunderFee] = useState(5)
  const [logistics, setLogistics] = useState(15000)

  const cogs          = poValue * (cogsPct / 100)
  const gross         = poValue - cogs - logistics
  const funderFeeAmt  = poValue * (funderFee / 100)
  const net           = gross - funderFeeAmt
  const netPct        = poValue > 0 ? (net / poValue) * 100 : 0
  const viable        = net > 0 && netPct >= 8

  const verdict =
    net <= 0
      ? { text: '✗ Loss-making deal. Funders will decline. Renegotiate COGS.', ok: false }
      : netPct < 8
      ? { text: '⚠ Tight margin. Negotiate supplier pricing or funder fees first.', ok: false }
      : { text: '✓ Deal is fundable. Strong margin for a funder application.', ok: true }

  const ResultRow = ({ label, value, color }) => (
    <div>
      <div
        style={{
          fontSize: 10,
          color: 'rgba(255,255,255,0.45)',
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
          marginBottom: 2,
        }}
      >
        {label}
      </div>
      <div style={{ fontSize: 14, fontWeight: 700, color }}>{value}</div>
    </div>
  )

  return (
    <div style={{ padding: '0 4px' }}>
      <h3 style={{ fontSize: 15, fontWeight: 700, color: C.ink, marginBottom: 4 }}>
        Deal Profitability Calculator
      </h3>
      <p style={{ fontSize: 12, color: C.muted, marginBottom: 20, lineHeight: 1.5 }}>
        Model your unit economics before applying — funders will run the same numbers.
      </p>

      <Slider
        label="PO Value"
        value={poValue}
        onChange={setPoValue}
        min={50000}
        max={5000000}
        step={10000}
        displayValue={formatZAR(poValue)}
      />
      <Slider
        label="Cost of Goods (COGS)"
        value={cogsPct}
        onChange={setCogsPct}
        min={30}
        max={90}
        displayValue={`${cogsPct}% of PO`}
      />
      <Slider
        label="Logistics & Other Costs"
        value={logistics}
        onChange={setLogistics}
        min={0}
        max={200000}
        step={1000}
        displayValue={formatZAR(logistics)}
      />
      <Slider
        label="Funder Fee"
        value={funderFee}
        onChange={setFunderFee}
        min={2}
        max={12}
        step={0.5}
        displayValue={`${funderFee}% of PO`}
      />

      {/* Results panel */}
      <div style={{ background: C.navyMid, borderRadius: 12, padding: 16, marginTop: 8 }}>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: 12,
            marginBottom: 12,
          }}
        >
          <ResultRow label="PO Value"   value={formatZAR(poValue)}     color="white" />
          <ResultRow label="COGS"       value={`–${formatZAR(cogs)}`}  color="#fc8181" />
          <ResultRow label="Logistics"  value={`–${formatZAR(logistics)}`} color="#fc8181" />
          <ResultRow label="Funder Fee" value={`–${formatZAR(funderFeeAmt)}`} color="#fbd38d" />
        </div>

        <div
          style={{
            borderTop: '1px solid rgba(255,255,255,0.1)',
            paddingTop: 12,
            marginBottom: 12,
          }}
        >
          <div
            style={{
              fontSize: 11,
              color: 'rgba(255,255,255,0.45)',
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              marginBottom: 4,
            }}
          >
            Your Net Profit
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, flexWrap: 'wrap' }}>
            <span
              style={{
                fontSize: 24,
                fontWeight: 800,
                color: viable ? '#68d391' : '#fc8181',
              }}
            >
              {formatZAR(net)}
            </span>
            <span
              style={{
                fontSize: 13,
                fontWeight: 600,
                color: viable ? '#68d391' : '#fc8181',
              }}
            >
              ({netPct.toFixed(1)}% margin)
            </span>
          </div>
        </div>

        <div
          style={{
            padding: '8px 12px',
            borderRadius: 8,
            background: verdict.ok
              ? 'rgba(42,125,79,0.25)'
              : 'rgba(192,82,42,0.25)',
          }}
        >
          <span
            style={{
              fontSize: 12,
              fontWeight: 600,
              color: verdict.ok ? '#68d391' : '#fc8181',
            }}
          >
            {verdict.text}
          </span>
        </div>
      </div>

      {/* Disclaimer */}
      <p
        style={{
          fontSize: 10,
          color: C.muted,
          marginTop: 14,
          lineHeight: 1.5,
          textAlign: 'center',
        }}
      >
        Illustrative only. Actual funder fees vary by deal, funder, and risk profile.
      </p>
    </div>
  )
}
