import { C } from '../tokens.js'

export const STEPS = [
  { id: 1,  icon: '📋', label: 'PO Received',        short: 'Confirm Order',   color: C.navy    },
  { id: 2,  icon: '🧮', label: 'Cost & Quote',        short: 'Run Numbers',     color: C.navyMid },
  { id: 3,  icon: '🏦', label: 'Select Funder',       short: 'Choose Partner',  color: C.navyLt  },
  { id: 4,  icon: '📤', label: 'Submit Application',  short: 'Upload Docs',     color: C.gold    },
  { id: 5,  icon: '🔍', label: 'Due Diligence',       short: 'Funder Reviews',  color: C.gold    },
  { id: 6,  icon: '✍️', label: 'Approval & Sign',     short: 'Sign Agreement',  color: C.goldLt  },
  { id: 7,  icon: '💳', label: 'Supplier Paid',       short: 'Funder Pays',     color: C.sage    },
  { id: 8,  icon: '🚚', label: 'Deliver Goods',       short: 'Fulfil Order',    color: C.sage    },
  { id: 9,  icon: '💰', label: 'Customer Pays',       short: 'Invoice Settled', color: C.sage    },
  { id: 10, icon: '🎯', label: 'Profit Released',     short: 'You Get Paid',    color: C.sageDk  },
]

export const STEP_DETAILS = {
  1: {
    title: 'Valid Purchase Order',
    description:
      'You hold a confirmed order from a credible customer. The PO must clearly state quantities, delivery timelines, and payment terms. Funders only finance legitimate, verifiable orders.',
    checklist: [
      'Customer name & contact details',
      'Itemised quantities & specs',
      'Agreed delivery date',
      'Payment terms (30/60/90 days)',
      'PO reference number',
    ],
    tip: 'Government or listed-company POs unlock the best funding rates — funders love strong counterparties.',
    actor: 'YOU',
    actorColor: C.navy,
  },
  2: {
    title: 'Cost & Profit Calculation',
    description:
      'Get supplier quotes and model the full unit economics. Funders check that the deal is profitable after their fees — loss-making transactions are declined automatically.',
    checklist: [
      'Supplier quotes (at least 2)',
      'Total cost of goods (COGS)',
      'Logistics & delivery costs',
      'Funder fee (typically 3–8%)',
      'Net margin confirmation (>10% recommended)',
    ],
    tip: 'Build a simple margin model. If profit after funder fees drops below 10%, renegotiate supplier pricing first.',
    actor: 'YOU',
    actorColor: C.navy,
  },
  3: {
    title: 'Choose a Funder',
    description:
      'Select a PO funding provider suited to your deal size and industry. Compare fees, advance percentages, turnaround times, and sector experience before applying.',
    checklist: [
      'Fee structure (flat % vs tiered)',
      'Advance % of PO value (typically 70–100%)',
      'Minimum/maximum deal sizes',
      'Industry experience',
      'Speed of first contact & approval',
    ],
    tip: 'Specialist fintech lenders often beat banks on speed. Banks may offer lower rates for deals >R500k.',
    actor: 'YOU',
    actorColor: C.navy,
  },
  4: {
    title: 'Submit Application & Documents',
    description:
      'Applications are short — typically minutes online. A representative usually contacts you the same or next business day.',
    checklist: [
      'Signed purchase order',
      'Supplier quotes',
      'Customer contact (for PO verification)',
      'CIPC company registration',
      'Director IDs (certified copy)',
      '3 months bank statements',
      'Tax clearance certificate',
    ],
    tip: 'Pre-package all documents in a single folder before applying. Gaps in docs are the #1 cause of delays.',
    actor: 'YOU',
    actorColor: C.navy,
  },
  5: {
    title: 'Funder Due Diligence',
    description:
      'The funder independently verifies the PO with your customer, assesses their creditworthiness, checks supplier capability, and confirms deal profitability.',
    checklist: [
      'PO authenticity confirmed',
      'Customer credit check',
      'Supplier capability assessed',
      'Deal margin validated',
      'Director background check',
      'Structured proposal issued',
    ],
    tip: 'Expect 2–5 business days for standard deals. Complex or high-value deals may take up to 2 weeks.',
    actor: 'FUNDER',
    actorColor: C.gold,
  },
  6: {
    title: 'Approval & Funding Agreement',
    description:
      'Review and sign the funding terms: fees, repayment structure, and the supplier payment schedule. Once signed, the funder prepares to advance payment.',
    checklist: [
      'Fee percentage agreed',
      'Repayment source confirmed (customer payment)',
      'Supplier payment schedule',
      'Dispute resolution clause',
      'Cession of invoice signed',
    ],
    tip: 'Ensure the repayment is tied specifically to this customer's payment — not a general business liability.',
    actor: 'BOTH',
    actorColor: C.goldLt,
  },
  7: {
    title: 'Supplier Paid Directly',
    description:
      'The funder pays your suppliers directly — not you. This ensures funds are strictly ring-fenced for fulfilling the order, protecting both parties.',
    checklist: [
      'Supplier bank details verified',
      'Payment advice issued to supplier',
      'Goods/services production begins',
      'Proof of payment retained',
    ],
    tip: 'Never accept a funder who pays you instead of the supplier — this is a red flag for predatory lenders.',
    actor: 'FUNDER',
    actorColor: C.gold,
  },
  8: {
    title: 'Production & Delivery',
    description:
      'Suppliers deliver goods or services. You complete the order and deliver to your customer according to the PO terms and agreed delivery schedule.',
    checklist: [
      'Goods received from supplier',
      'Quality check completed',
      'Delivery to customer confirmed',
      'Proof of delivery (POD) signed',
      'Invoice issued to customer',
    ],
    tip: 'Keep your POD. It triggers your customer's payment obligation and starts the clock on their terms.',
    actor: 'YOU',
    actorColor: C.navy,
  },
  9: {
    title: 'Customer Payment',
    description:
      'Your customer pays the funder directly (or into a ceded/controlled account). This settles the advance plus the agreed funder fees.',
    checklist: [
      'Customer payment received by funder',
      'Advance amount settled',
      'Funder fees deducted',
      'Reconciliation statement issued',
    ],
    tip: 'Chase your customer proactively as their due date approaches — late payment extends your funder's holding period and may trigger penalty fees.',
    actor: 'CUSTOMER',
    actorColor: C.sienna,
  },
  10: {
    title: 'Profit Released to You',
    description:
      'After the funder deducts their fees from the customer's payment, the remaining balance — your profit — is paid directly to your business account.',
    checklist: [
      'Funder fees deducted',
      'Remaining balance transferred to you',
      'Transaction closed',
      'Deal report for records',
    ],
    tip: 'Use this profit to build a track record. Repeat successful deals unlock higher advance limits and lower fees.',
    actor: 'YOU',
    actorColor: C.sage,
  },
}

export const FUNDERS = [
  {
    name: 'Merchant Factors',
    type: 'Specialist',
    fee: '3–6%',
    advance: 'Up to 100%',
    min: 'R50k',
    speed: '24–48 hrs',
    strength: 'Manufacturing, retail, food',
    url: 'https://www.merchantfactors.co.za',
  },
  {
    name: 'Lula',
    type: 'Fintech',
    fee: '4–8%',
    advance: '70–90%',
    min: 'R20k',
    speed: 'Same day',
    strength: 'SME-focused, fast digital',
    url: 'https://www.lula.co.za',
  },
  {
    name: 'Retail Capital',
    type: 'Fintech',
    fee: '3–7%',
    advance: 'Up to 100%',
    min: 'R50k',
    speed: '48 hrs',
    strength: 'Retail, FMCG, distribution',
    url: 'https://www.retailcapital.co.za',
  },
  {
    name: 'Standard Bank BizFlex',
    type: 'Bank',
    fee: 'Prime + 2%',
    advance: '80%',
    min: 'R500k',
    speed: '5–10 days',
    strength: 'Established SMMEs, large POs',
    url: 'https://www.standardbank.co.za/southafrica/business/products-and-services/borrow-for-your-business',
  },
  {
    name: 'Nedbank SMME Finance',
    type: 'Bank',
    fee: 'Prime + 3%',
    advance: '70–80%',
    min: 'R250k',
    speed: '5–7 days',
    strength: 'Govt contracts, construction',
    url: 'https://www.nedbank.co.za/content/nedbank/desktop/gt/en/business/business-solutions/grow-my-business.html',
  },
  {
    name: 'Bridgement',
    type: 'Fintech',
    fee: '3–6%',
    advance: 'Up to 90%',
    min: 'R10k',
    speed: 'Same day',
    strength: 'Fast approval, all sectors',
    url: 'https://www.bridgement.com',
  },
]

export const TIMELINE = [
  { label: 'Application',       value: 'Minutes',                     highlight: false },
  { label: 'First Contact',     value: 'Same / next business day',    highlight: false },
  { label: 'Document Review',   value: '2–5 business days',           highlight: false },
  { label: 'Supplier Payment',  value: 'Immediately after signing',   highlight: true  },
  { label: 'Total Cycle',       value: '30–90 days (customer terms)', highlight: false },
]

export const WHY_SMMES = [
  { icon: '💼', text: 'Take on large contracts without upfront capital' },
  { icon: '🛡️', text: 'Protects your monthly cash flow' },
  { icon: '⚡', text: 'Faster approval than traditional bank loans' },
  { icon: '📈', text: "Based on your customer's strength, not your balance sheet" },
  { icon: '🔄', text: 'Repeat deals build a track record for better rates' },
]
